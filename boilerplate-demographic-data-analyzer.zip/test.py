import pandas as pd


def calculate_demographic_data(print_data=True):
    # Read data from file
    df = pd.read_csv('adult.data.csv')
    df.head()

    
    highed = (df['education'] == 'Bachelors') | (df['education'] == 'Masters')| (df['education']== 'Doctorate')
    lowed = (~df['education'] == 'Bachelors') & (~df['education'] == 'Masters') & (~df['education']== 'Doctorate')
    higher_education = highed.count().dropna()
    lower_education = lowed.count().dropna()